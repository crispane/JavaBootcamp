package ExtraClasses;

/**
 *
 * @author Chrysanthos Panagakos
 */

// Wrapper class for all Base Classes (*Course*, *Student*, *Assignment*, *Trainer*) and *ItemList*
public abstract class Item {
	public abstract String getName();
}
